<?php
//Rutas globales
define("PATH_MODEL", __DIR__ . "/model/");
define("PATH_CONTROLLER", __DIR__ . "/controller/");
